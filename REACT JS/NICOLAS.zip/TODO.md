# TODO for Adding Edit and Delete Buttons to PersonDetails.js

- [x] Add edit mode UI: Button to start editing, input for name, save and cancel buttons when editing.
- [x] Add delete button with confirmation.
- [x] Test the functionality by running the app and verifying buttons work.
